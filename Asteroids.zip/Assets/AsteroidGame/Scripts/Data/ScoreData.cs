using Unity.Entities;
using Unity.Transforms;
using UnityEngine;



public class ScoreData : MonoBehaviour
{

    public  static int score;



    private void Update()
    {
        Debug.Log(score);
    }

}

